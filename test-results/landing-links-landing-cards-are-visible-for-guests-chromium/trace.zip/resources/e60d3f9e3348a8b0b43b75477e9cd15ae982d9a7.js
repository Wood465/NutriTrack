(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/8daba_next_dist_client_df5e07e9._.js",
  "static/chunks/app_ui_global_ed6f8068.css"
],
    source: "dynamic"
});
