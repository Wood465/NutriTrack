(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_31493fba._.js",
  "static/chunks/app_stats_728d67f3._.js"
],
    source: "dynamic"
});
