(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9e8e2219._.js",
  "static/chunks/8daba_next_dist_compiled_react-dom_56281118._.js",
  "static/chunks/8daba_next_dist_compiled_react-server-dom-turbopack_c9bf6be8._.js",
  "static/chunks/8daba_next_dist_compiled_next-devtools_index_4d214ecd.js",
  "static/chunks/8daba_next_dist_compiled_d86586ad._.js",
  "static/chunks/8daba_next_dist_client_de897700._.js",
  "static/chunks/8daba_next_dist_20538b45._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
